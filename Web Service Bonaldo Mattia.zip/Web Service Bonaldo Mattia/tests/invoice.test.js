//Test
const request = require('supertest');
const app = require('./app');

describe('Test the invoice endpoints', () => {
  let invoiceId;

  test('GET / should return a list of invoices', async () => {
    const response = await request(app).get('/invoices');
    expect(response.status).toBe(200);
    expect(response.body.r).toBeInstanceOf(Array);
  });

  test('POST / should create a new invoice', async () => {
    const invoice = {
      data: '1970-01-01',
      utente: 1,
      indirizzata: 'ACL s.r.l',
      motivazioni: 'Fattura a favore di ACL s.r.l per realizzazione sito web',
      somma: 25849,
    };

    const response = await request(app)
      .post('/invoices')
      .send(invoice);
    expect(response.status).toBe(201);
    expect(response.body).toMatchObject(invoice);

    invoiceId = response.body.id;
  });

  test('PUT /update/:id should update an existing invoice', async () => {
    const invoiceUpdates = {
      data: '1970-01-01',
      utente: 1,
      indirizzata: 'ACL s.r.l',
      motivazioni: 'Fattura a favore di ACL s.r.l per realizzazione sito web',
      somma: 25849,
    };

    const response = await request(app)
      .put(`/invoices/update/${invoiceId}`)
      .send(invoiceUpdates);
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject(invoiceUpdates);
  });

  test('DELETE /delete/:id should delete an existing invoice', async () => {
    const response = await request(app).delete(`/invoices/delete/${invoiceId}`);
    expect(response.status).toBe(204);

    const getResponse = await request(app).get(`/invoices/${invoiceId}`);
    expect(getResponse.status).toBe(404);
  });
});
