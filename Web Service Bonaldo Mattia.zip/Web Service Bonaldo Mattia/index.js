const swaggerJSDoc = require('swagger-jsdoc');
const swaggerUI = require('swagger-ui-express');
const {app, port} = require("./lib/appServer")
const router = require("./routes/router")

app.use("/invoice", router);
const swaggerOptions = {
  swaggerDefinition: {
    info: {
      title: 'TokTik API',
      description: 'API del progetto TokTik sviluppato dal Gruppo 3',
    },
  },
  apis: ['./routes/*.js'],
};
const swaggerDocs = swaggerJSDoc(swaggerOptions);
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerDocs));
app.listen(port, () => {
  console.log("API attivata, in attesa sulla porta: "+ port)
})

/*
const swaggerJSDoc = require('swagger-jsdoc');
const swaggerUI = require('swagger-ui-express');
const { app, port } = require("./lib/appServer");
const router = require("./routes/router");

function start() {
  app.use("/invoice", router);

  const swaggerOptions = {
    swaggerDefinition: {
      info: {
        title: 'TokTik API',
        description: 'API del progetto TokTik sviluppato dal Gruppo 3',
      },
    },
    apis: ['./routes/*.js'],
  };

  const swaggerDocs = swaggerJSDoc(swaggerOptions);

  app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerDocs));

  app.listen(port, () => {
    console.log(`API attivata, in attesa sulla porta: ${port}`);
  });
}

module.exports = start;
*/